import React, { useState, useContext, useEffect } from "react";
import { updateDoc, doc, getDoc } from "firebase/firestore";
import { db, storage } from "../../firebase";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "../../context/AuthContext";
import { ref, uploadBytesResumable, getDownloadURL } from "firebase/storage";

const StartupDetails = () => {
  const [newDetails, setNewDetails] = useState({
    companyName: "",
    amountInvested: "",
    profitMargin: "",
    equity: "",
    cin: "",
    revenue: "",
    companyDescription: "",
    logo: "", // Add logo field to newDetails
  });

  const [file, setFile] = useState(null);
  const [uploadProgress, setUploadProgress] = useState(null);
  const [isImageUploaded, setIsImageUploaded] = useState(false);

  const navigate = useNavigate();
  const { currentUser } = useContext(AuthContext);

  useEffect(() => {
    const uploadFile = async () => {
      if (file && !isImageUploaded) {
        const name = `${currentUser.uid}`;
        const storageRef = ref(storage, `startupLogos/${name}`);
        const uploadTask = uploadBytesResumable(storageRef, file);

        uploadTask.on(
          "state_changed",
          (snapshot) => {
            const progress =
              (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
            setUploadProgress(progress);
          },
          (error) => {
            console.error("Error uploading file:", error);
          },
          async () => {
            const downloadURL = await getDownloadURL(uploadTask.snapshot.ref);
            // Update the logo field in newDetails
            setNewDetails((prevDetails) => ({
              ...prevDetails,
              logo: downloadURL,
            }));
            setIsImageUploaded(true); // Set the flag to true after the upload
          }
        );
      }
    };

    uploadFile();
  }, [file, currentUser, isImageUploaded]); // Include isImageUploaded in the dependency array

  const handleFormSubmit = async (e) => {
    e.preventDefault();

    const userDocRef = doc(db, "users", currentUser.uid);

    try {
      // Check if the user document already exists
      const userDoc = await getDoc(userDocRef);

      if (userDoc.exists()) {
        // Update the existing document with the selected details
        await updateDoc(userDocRef, {
          startupDetails: newDetails,
        });
      } else { 
        console.error("User document does not exist.");
        // Handle the case where the user document doesn't exist
      }

      // Navigate to the appropriate dashboard route
      navigate(`/dashboard/startup`);
    } catch (error) {
      console.error("Error updating user document:", error);
      // Handle error appropriately, e.g., show an error message to the user
    }
  };

  const handleChange = (e) => {
    setNewDetails({ ...newDetails, [e.target.name]: e.target.value });
  };

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    setFile(selectedFile);
  };

  return (
    <form onSubmit={handleFormSubmit}>
      <h3>Update your startup details</h3>

      <label>
        Logo:
        <input type="file" onChange={handleFileChange} />
        {uploadProgress !== null && (
          <div>Upload Progress: {uploadProgress.toFixed(2)}%</div>
        )}
      </label>

      <label>
        Company Name:
        <input
          type="text"
          name="companyName"
          value={newDetails.companyName}
          onChange={handleChange}
        />
      </label>

      <label>
        Amount Invested:
        <input
          type="text"
          name="amountInvested"
          value={newDetails.amountInvested}
          onChange={handleChange}
        />
      </label>

      <label>
        Profit Margin:
        <input
          type="text"
          name="profitMargin"
          value={newDetails.profitMargin}
          onChange={handleChange}
        />
      </label>

      <label>
        Equity:
        <input
          type="text"
          name="equity"
          value={newDetails.equity}
          onChange={handleChange}
        />
      </label>

      <label>
        CIN:
        <input type="text" name="cin" value={newDetails.cin} onChange={handleChange} />
      </label>

      <label>
        Revenue:
        <input
          type="text"
          name="revenue"
          value={newDetails.revenue}
          onChange={handleChange}
        />
      </label>

      <label>
        Company Description:
        <textarea
          name="companyDescription"
          value={newDetails.companyDescription}
          onChange={handleChange}
        ></textarea>
      </label>

      <button type="submit">Save Details</button>
    </form>
  );
};

export default StartupDetails;
