import React, { useState, useContext } from "react";
import { useNavigate } from "react-router-dom";
import { updateDoc, doc, getDoc } from "firebase/firestore";
import { db } from "../../firebase";
import { AuthContext } from "../../context/AuthContext";
import "./selection.scss";

const Selection = () => {
  const [selectedType, setSelectedType] = useState("");
  const navigate = useNavigate();
  const { currentUser } = useContext(AuthContext);

  const handleSelection = async () => {
    if (selectedType && currentUser) {
      const userDocRef = doc(db, "users", currentUser.uid);

      try {
        // Check if the user document already exists
        const userDoc = await getDoc(userDocRef);

        if (userDoc.exists()) {
          // Update the existing document with the selected details, including accType
          await updateDoc(userDocRef, {
            accType: selectedType,
          });
        } else {
          console.error("User document does not exist.");
          // Handle the case where the user document doesn't exist
        }

        // Navigate to the appropriate details route
        navigate(`/details/${selectedType}`);
      } catch (error) {
        console.error("Error updating user document:", error);
        // Handle error appropriately, e.g., show an error message to the user
      }
    }
  };

  return (
    <div className="selection">
      <h2>Select Your Account Type</h2>
      <div className="options">
        <label>
          <input
            type="radio"
            value="startup"
            checked={selectedType === "startup"}
            onChange={() => setSelectedType("startup")}
          />
          Startup
        </label>
        <label>
          <input
            type="radio"
            value="investor"
            checked={selectedType === "investor"}
            onChange={() => setSelectedType("investor")}
          />
          Investor
        </label>
        <label>
          <input
            type="radio"
            value="incubator"
            checked={selectedType === "incubator"}
            onChange={() => setSelectedType("incubator")}
          />
          Incubator
        </label>
        <label>
          <input
            type="radio"
            value="accelerator"
            checked={selectedType === "accelerator"}
            onChange={() => setSelectedType("accelerator")}
          />
          Accelerator
        </label>
      </div>
      <button onClick={handleSelection}>Continue</button>
    </div>
  );
};

export default Selection;
