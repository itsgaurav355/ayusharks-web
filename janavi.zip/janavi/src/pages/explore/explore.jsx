import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { collection, getDocs } from 'firebase/firestore';
import { db } from '../../firebase';

const Explore = () => {
  const navigate = useNavigate();

  const [users, setUsers] = useState([]);
  const [search, setSearch] = useState('');
  const [selectedUser, setSelectedUser] = useState(null);

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const usersCollection = collection(db, 'users');
        const usersSnapshot = await getDocs(usersCollection);
        const usersData = usersSnapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
        setUsers(usersData);
      } catch (error) {
        console.error('Error fetching users:', error);
      }
    };

    fetchUsers();
  }, []); // Fetch users on component mount

  const sortFirstName = () => {
    setUsers([...users].sort((a, b) =>
      a.first_name.localeCompare(b.first_name)
    ));
  };

  const toggleDetails = (index) => {
    setSelectedUser(selectedUser === index ? null : index);
  };

  const navigateToUserDetails = (userId) => {
    navigate(`/user-details/${userId}`);
  };

  return (
    <div className="bg-white p-8 rounded-lg shadow-md w-3/4 mx-auto mt-8">
      <div className="flex items-center mb-8">
        <div className="flex-shrink-0">
          <span className="text-lg font-semibold tracking-widest text-gray-900 uppercase rounded-lg dark-mode:text-white focus:outline-none focus:shadow-outline">TOP STARTUPS</span>
        </div>
        <div className="ml-auto">
          <input
            type="text"
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search users"
            className="border p-3 rounded-l-md focus:outline-none focus:ring focus:border-blue-300"
          />
          <button onClick={sortFirstName} className="bg-blue-500 text-white p-3 rounded-r-md">
            Sort by First Name
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {users
          .filter((user) => {
            const lowerCaseSearch = search.toLowerCase();
            return lowerCaseSearch === '' ||
              (user.email && user.email.toLowerCase().includes(lowerCaseSearch));
          })
          .map((user, index) => (
            <div key={user.id} className="w-full bg-white rounded-lg p-8 flex flex-col justify-between items-center relative" style={{ height: '400px' }}>
              <div className="w-full h-2/3 mb-4">
                <div
                  className="h-full w-full bg-cover bg-center rounded-md"
                  style={{ backgroundImage: `url(${user.image})` }}
                ></div>
              </div>
              <div className="text-center">
                <p className="text-xl text-black-700 font-bold mb-2">{user.email}</p>
              </div>
              {selectedUser === index && (
                <div className="mt-4">
                  <p>{user.accType}</p>
                </div>
              )}
              <button
                onClick={() => navigateToUserDetails(user.id)}
                className="bg-blue-500 text-white py-2 px-4 rounded-md hover:bg-blue-700 mt-4"
              >
                View Details
              </button>
            </div>
          ))}
      </div>
    </div>
  );
};

export default Explore;
