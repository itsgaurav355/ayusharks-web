import React, { useEffect, useState } from 'react';
import { db } from '../../firebase';
import { collection, addDoc, query, orderBy, onSnapshot } from 'firebase/firestore';
import { useAuth } from '../../context/AuthContext'; // Adjust the path based on your file structure

const Chat = ({ otherUserId }) => {
  const { currentUser } = useAuth();
  const [messages, setMessages] = useState([]);
  const [messageInput, setMessageInput] = useState('');

  const sendMessage = async () => {
    try {
      if (!currentUser) {
        throw new Error('No authenticated user.');
      }

      if (!otherUserId) {
        throw new Error('No recipient specified.');
      }

      if (messageInput.trim() === '') {
        throw new Error('Empty message.');
      }

      const timestamp = new Date();

      const newMessage = {
        senderId: currentUser.uid,
        senderEmail: currentUser.email,
        receiverId: otherUserId,
        message: messageInput,
        timestamp: timestamp,
      };

      const ids = [currentUser.uid, otherUserId].sort();
      const chatRoomId = ids.join('_');

      await addDoc(collection(db, `chat_rooms/${chatRoomId}/messages`), newMessage);

      setMessageInput('');
    } catch (error) {
      console.error('Error sending message:', error.message);
    }
  };

  useEffect(() => {
    const getMessages = () => {
      if (currentUser && otherUserId) {
        const ids = [currentUser.uid, otherUserId].sort();
        const chatRoomId = ids.join('_');
        const messagesCollection = collection(db, `chat_rooms/${chatRoomId}/messages`);

        const unsubscribe = onSnapshot(query(messagesCollection, orderBy('timestamp', 'asc')), (snapshot) => {
          const messagesArray = snapshot.docs.map((doc) => doc.data());
          setMessages(messagesArray);
        });

        return () => unsubscribe();
      }
    };

    return getMessages();
  }, [currentUser, otherUserId]);

  return (
    <div className="container mx-auto p-4">
      <div className="bg-gray-200 p-4 rounded-md mb-4">
        {/* Render your messages here */}
        {messages.map((msg, index) => (
          <div key={index} className="mb-2">
            <p className="text-blue-500">{msg.senderEmail}: {msg.message}</p>
          </div>
        ))}
      </div>

      {/* Input for sending new messages */}
      <div className="flex items-center">
        <input
          type="text"
          value={messageInput}
          onChange={(e) => setMessageInput(e.target.value)}
          placeholder="Type your message..."
          className="flex-grow p-2 border rounded-l-md"
        />
        <button
          onClick={sendMessage}
          className="bg-blue-500 text-white p-2 rounded-r-md"
        >
          Send
        </button>
      </div>
    </div>
  );
};

export default Chat;
