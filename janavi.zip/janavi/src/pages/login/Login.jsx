import React, { useState, useContext } from "react";
import { signInWithEmailAndPassword } from "firebase/auth";
import { AuthContext } from "../../context/AuthContext";
import { getDoc, doc } from "firebase/firestore";
import { auth, db } from "../../firebase";
import { Link, useNavigate } from "react-router-dom";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(null);
  const { dispatch } = useContext(AuthContext);
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();

    try {
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;

      // Assuming you have an 'accType' field in your user document
      const userDocRef = doc(db, "users", user.uid);
      const userDoc = await getDoc(userDocRef);

      if (userDoc.exists()) {
        const accType = userDoc.data().accType;

        // Dispatch login action with user data
        dispatch({ type: "LOGIN", payload: user });

        // Redirect based on accType
        navigate(`/dashboard/${accType}`);
      } else {
        setError("User document not found");
      }
    } catch (error) {
      setError(error.message);
    }
  };

  return (
    <div className="flex justify-center items-center min-h-screen bg-gray-900">
      <div className="bg-gray-800 px-10 py-10 rounded-xl w-full max-w-md">
        <h2 className="text-center text-white text-xl mb-4 font-bold">Login</h2>
        <form onSubmit={handleLogin} className="flex flex-col">
          <label className="text-white mb-2">Email:</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="input-field mb-4"
            required
          />

          <label className="text-white mb-2">Password:</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="input-field mb-4"
            required
          />

          <button
            type="submit"
            className="btn-primary w-full"
          >
            Login
          </button>
        </form>

        {error && <p className="text-red-500 mt-4">{error}</p>}

        <p className="text-white mt-4">
          Don't have an account yet?{" "}
          <Link to="/signup" className="text-blue-500 hover:underline">
            Sign up here
          </Link>
          .
        </p>
      </div>
    </div>
  );
};

export default Login;
