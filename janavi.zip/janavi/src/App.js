import React, { useContext, useState } from "react";
import { useParams } from "react-router-dom";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { productInputs, userInputs } from "./formSource";
import { DarkModeContext } from "./context/darkModeContext";
import { AuthContext } from "./context/AuthContext";
import "./styles.css"; // Import the styles.css file
import "./style.scss";
import Home from "./pages/home/Homepage";
import AccountProfile from "./pages/home/AccountProfile";
import Navbar from "./pages/home/Navbar";
import Login from "./pages/login/Login";
import List from "./pages/list/List";
import Single from "./pages/single/Single";
import New from "./pages/new/New";
import Selection from "./pages/selection/Selection";
import StartupDashboard from "./pages/dashboard/startup";
import InvestorDashboard from "./pages/dashboard/investor";
import IncubatorDashboard from "./pages/dashboard/incubator";
import AcceleratorDashboard from "./pages/dashboard/accelerator";
import StartupDetails from "./pages/details/startup";
import InvestorDetails from "./pages/details/investor";
import IncubatorDetails from "./pages/details/incubator";
import AcceleratorDetails from "./pages/details/accelerator";
import Signup from "./pages/signup/Signup";
import Chat from "./pages/chat/chat";
import AllUsers from "./pages/home/AllUsers";
import UserDetails from "./pages/home/Userdetails";
import Connections from "./pages/home/Connections";
import Requests from "./pages/home/Requests";
import Community from "./pages/chat/Community";
import GroupChat from "./pages/chat/Groupchat";
import Posts from "./pages/posts/Posts";
import Explore from "./pages/explore/explore";
import Resource from "./pages/resource/resource";


function App() {
  const { darkMode } = useContext(DarkModeContext);
  const { currentUser } = useContext(AuthContext);
  const [selectedUser, setSelectedUser] = useState(null);

  const RequireAuth = ({ children }) => {
    return currentUser ? children : <Navigate to="/login" />;
  };

  return (
    <div className={darkMode ? "app dark" : "app"}>
      <BrowserRouter>
        <Navbar />
        <Routes>
          <Route path="/">
            <Route path="login" element={<Login />} />
            <Route path="signup" element={<Signup />} />
            <Route path="/chat/:userId" element={<RequireAuth><ChatContainer /></RequireAuth>} />
            <Route path="community/:groupId" element={<RequireAuth><Groupchatcontainer /></RequireAuth>} />
            <Route path="posts" element={<Posts />} />
            <Route path="user-details/:userId" element={<RequireAuth><UserDetails /></RequireAuth>} />
            <Route path="/connections" element={<RequireAuth><Connections /></RequireAuth>} />
            <Route path="/explore" element={<RequireAuth><Explore /></RequireAuth>} />
            <Route path="/resource" element={<RequireAuth><Resource /></RequireAuth>} />
            <Route path="/community" element={<RequireAuth><Community /></RequireAuth>} />
            <Route path="/requests" element={<RequireAuth><Requests /></RequireAuth>} />
            <Route index element={<RequireAuth><Home selectedUser={selectedUser} onSelectUser={setSelectedUser} /></RequireAuth>} />
            <Route path="all-users" element={<AllUsers selectedUser={selectedUser} onSelectUser={setSelectedUser} />} />
            <Route path="account-profile" element={<RequireAuth><AccountProfile /></RequireAuth>} />
            <Route path="dashboard/:dashboardType" element={<RequireAuth><DashboardRouter /></RequireAuth>} />
            <Route path="selection" element={<RequireAuth><Selection /></RequireAuth>} />
            <Route path="users">
              <Route index element={<RequireAuth><List /></RequireAuth>} />
              <Route path=":userId" element={<RequireAuth><Single /></RequireAuth>} />
              <Route path="new" element={<RequireAuth><New inputs={userInputs} title="Add New User" /></RequireAuth>} />
            </Route>
            <Route path="products">
              <Route index element={<RequireAuth><List /></RequireAuth>} />
              <Route path=":productId" element={<RequireAuth><Single /></RequireAuth>} />
              <Route path="new" element={<RequireAuth><New inputs={productInputs} title="Add New Product" /></RequireAuth>} />
            </Route>
            {/* Add a new route for user details */}
            <Route path="details/:detailType" element={<RequireAuth><DetailsRouter /></RequireAuth>} />
          </Route>
        </Routes>
      </BrowserRouter>
    </div>
  );
}

const DashboardRouter = () => {
  const { dashboardType } = useParams();

  switch (dashboardType) {
    case 'startup':
      return <StartupDashboard />;
    case 'investor':
      return <InvestorDashboard />;
    case 'incubator':
      return <IncubatorDashboard />;
    case 'accelerator':
      return <AcceleratorDashboard />;
    default:
      return <Navigate to="/" />;
  }
};

const DetailsRouter = () => {
  const { detailType } = useParams();

  switch (detailType) {
    case 'startup':
      return <StartupDetails />;
    case 'investor':
      return <InvestorDetails />;
    case 'incubator':
      return <IncubatorDetails />;
    case 'accelerator':
      return <AcceleratorDetails />;
    default:
      return <Navigate to="/" />;
  }
};

const ChatContainer = () => {
  const { userId } = useParams();

  // Render the Chat component with the userId
  return <Chat otherUserId={userId} />;
};

const Groupchatcontainer = () => {
  const { selectedGroup } = useParams();

  // Render the Chat component with the userId
  return <GroupChat groupId={selectedGroup} />;
};

export default App;
